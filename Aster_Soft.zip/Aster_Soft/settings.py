SHUFFLE_WALLETS     = True
RETRY               = 3

# --- GENERAL SETTINGS ---
THREADS             = 1  # Оставить 1 для стабильности

TOKENS_TO_TRADE     = {
    "SOL"           : {
        "prices"    : [100, 260],
        "leverage"  : [3, 4],
        "open_price": [0.0, 0.0],
    },
    "ETH"           : {
        "prices"    : [3000, 4800],
        "leverage"  : [3, 4],
        "open_price": [0.0, 0.0],
    },
    "BTC"           : {
        "prices"    : [100000, 130000],
        "leverage"  : [3, 4],
        "open_price": [0.0, 0.0],
    },
}

FUTURE_ACTIONS      = {
    "Long"          : True,
    "Short"         : True,  # Или выбери одно направление
}

TRADES_COUNT        = [15, 30]  # Уменьшил для меньшего риска

# --- ORDER SETTINGS ---
TRADE_AMOUNTS       = {
    "amount"        : [25, 40],  # Более консервативно
    "percent"       : [0, 0],
}

FUTURES_LIMITS      = {
    "close_previous"        : True,
    "price_diff_amount"     : [0.0, 0.0],
    "price_diff_percent"    : [0.8, 1.2],  # Более реалистично
    "to_wait"               : 5,
}

STOP_LOSS_SETTING   = {
    "enable"                : True,
    "loss_diff_amount"      : [0.0, 0.0],
    "loss_diff_percent"     : [1.2, 2.0],  # Увеличил для волатильности
}

CANCEL_ORDERS       = {
    "orders"        : True,
    "positions"     : True,
}

PAIR_SETTINGS       = {
    "pair_amount"   : [2, 3],  # Меньше одновременных позиций
    "position_hold" : [180, 300],  # 3-5 минут
}

# --- SLEEP SETTINGS ---
SLEEP_BETWEEN_OPEN_ORDERS  = [15, 25]
SLEEP_BETWEEN_CLOSE_ORDERS = [15, 25]
SLEEP_AFTER_FUTURE  = [150, 240]  # 2.5-4 минуты
SLEEP_AFTER_ACC     = [240, 360]  # 4-6 минут

TG_BOT_TOKEN        = ''
TG_USER_ID          = []