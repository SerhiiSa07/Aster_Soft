from urllib.parse import urlencode
from aiohttp import ClientSession
from decimal import Decimal
from hashlib import sha256
from loguru import logger
from time import time
import hmac
import random
import asyncio

# Імпортуємо налаштування
from settings import (
    SHUFFLE_WALLETS, RETRY, THREADS, TOKENS_TO_TRADE, FUTURE_ACTIONS,
    TRADES_COUNT, TRADE_AMOUNTS, FUTURES_LIMITS, STOP_LOSS_SETTING,
    CANCEL_ORDERS, PAIR_SETTINGS, SLEEP_BETWEEN_OPEN_ORDERS,
    SLEEP_BETWEEN_CLOSE_ORDERS, SLEEP_AFTER_FUTURE, SLEEP_AFTER_ACC
)


class Browser:
    BASE_URL: str = "https://fapi.asterdex.com"

    def __init__(self, proxy: str, api_key: str, label: str):
        self.max_retries = RETRY
        self.api_key = api_key
        self.label = label

        if proxy not in ['https://log:pass@ip:port', 'http://log:pass@ip:port', 'log:pass@ip:port', '', None]:
            self.proxy = "http://" + proxy.removeprefix("https://").removeprefix("http://")
            logger.opt(colors=True).debug(f'[•] <white>{self.label}</white> | Got proxy <white>{self.proxy}</white>')
        else:
            self.proxy = None
            logger.opt(colors=True).warning(f'[-] <white>{self.label}</white> | Dont use proxies!')

        self.session = self.get_new_session()

    def get_new_session(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
            "Origin": "https://www.asterdex.com",
            "Referer": "https://www.asterdex.com/",
        }

        return ClientSession(headers=headers)

    async def close_session(self):
        if self.session:
            await self.session.close()

    def _build_signature(self, all_params: dict, method: str):
        query_string = urlencode(all_params)

        signature = hmac.new(
            self.api_key.split(':')[1].encode('utf-8'),
            query_string.encode('utf-8'),
            sha256
        ).hexdigest()

        return {
            "headers": {
                "X-MBX-APIKEY": self.api_key.split(':')[0],
            },
            "data" if method == "POST" else "params": {
                "signature": signature
            }
        }

    async def send_request(self, **kwargs):
        for attempt in range(self.max_retries):
            try:
                if kwargs.get("method"): 
                    kwargs["method"] = kwargs["method"].upper()
                if self.proxy:
                    kwargs["proxy"] = self.proxy

                if kwargs.get("build_signature"):
                    del kwargs["build_signature"]

                    # Get server time first
                    try:
                        async with self.session.request(
                            method="GET",
                            url=f'{self.BASE_URL}/fapi/v1/time',
                            proxy=self.proxy
                        ) as time_req:
                            time_data = await time_req.json()
                            server_time = time_data["serverTime"]
                    except:
                        server_time = int(time() * 1000)

                    if kwargs.get("params") is None:
                        kwargs["params"] = {}
                    kwargs["params"].update({
                        "timestamp": server_time,
                        "recvWindow": 10000,
                    })

                    if kwargs["method"] == "POST":
                        all_params = {**kwargs.get("params", {}), **kwargs.get("data", {})}
                        kwargs["data"] = all_params
                        if kwargs.get("params"): 
                            del kwargs["params"]
                    else:
                        all_params = kwargs.get("params", {})

                    for k, v in self._build_signature(all_params, kwargs["method"]).items():
                        if kwargs.get(k) is None:
                            kwargs[k] = v
                        else:
                            kwargs[k].update(v)

                async with self.session.request(**kwargs) as response:
                    data = await response.json()
                    
                    if 'code' in data and data['code'] != 200:
                        if attempt < self.max_retries - 1:
                            await asyncio.sleep(2 ** attempt)
                            continue
                        raise Exception(f"API Error: {data}")
                    
                    return data
                    
            except Exception as e:
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise e

    async def get_tokens_data(self):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v1/exchangeInfo',
        )
        if response.get("symbols") is None:
            raise Exception(f'Failed to get tokens data: {response}')
        return response["symbols"]

    async def create_order(self, order_data: dict):
        response = await self.send_request(
            method="POST",
            url=f'{self.BASE_URL}/fapi/v1/order',
            data=order_data,
            build_signature=True,
        )
        if response.get("orderId") is None:
            raise Exception(f'Failed to create order: {response}')
        return response

    async def get_balance(self):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v2/balance',
            build_signature=True,
        )
        if type(response) is not list:
            raise Exception(f'Failed to get balance: {response}')

        return next((float(token["availableBalance"]) for token in response if token["asset"] == "USDT"), 0)

    async def get_token_price(self, token_name: str):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v1/ticker/price',
            params={"symbol": token_name + "USDT"},
        )
        if response.get("price") is None:
            raise Exception(f'Failed to get {token_name} price: {response}')

        return Decimal(response["price"])

    async def get_leverages(self):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v4/account',
            build_signature=True,
        )
        if response.get("positions") is None:
            raise Exception(f'Failed to get leverages: {response}')

        return {p["symbol"].removesuffix("USDT"): int(p["leverage"]) for p in response["positions"]}

    async def change_leverage(self, token_name: str, leverage: int):
        response = await self.send_request(
            method="POST",
            url=f'{self.BASE_URL}/fapi/v1/leverage',
            data={
                "symbol": f"{token_name}USDT",
                "leverage": leverage,
            },
            build_signature=True,
        )
        if response.get("leverage") != leverage:
            raise Exception(f'Failed to change leverage: {response}')

        return True

    async def get_account_positions(self):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v2/positionRisk',
            build_signature=True,
        )
        if type(response) is not list:
            raise Exception(f'Failed to get account positions: {response}')

        return [p for p in response if Decimal(p["positionAmt"])]

    async def get_account_orders(self):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v1/openOrders',
            build_signature=True,
        )
        if type(response) is not list:
            raise Exception(f'Failed to get account orders: {response}')

        return response

    async def close_all_open_orders(self, token_name: str):
        response = await self.send_request(
            method="DELETE",
            url=f'{self.BASE_URL}/fapi/v1/allOpenOrders',
            params={"symbol": f"{token_name}USDT"},
            build_signature=True,
        )
        if response != {'code': 200, 'msg': 'The operation of cancel all open order is done.'}:
            raise Exception(f'Failed to close {token_name} orders: {response}')

        return True

    async def get_token_order_book(self, token_name: str):
        response = await self.send_request(
            method="GET",
            url=f'{self.BASE_URL}/fapi/v1/depth',
            params={"symbol": f"{token_name}USDT", "limit": 50},
        )
        if response.get("bids") is None or response.get("asks") is None:
            raise Exception(f'Failed to get {token_name} order book: {response}')

        return {"BUY": float(response["bids"][0][0]), "SELL": float(response["asks"][0][0])}


class TradingBot:
    def __init__(self, browser: Browser, wallet_label: str):
        self.browser = browser
        self.wallet_label = wallet_label
        self.trades_count = 0
        self.max_trades = random.randint(*TRADES_COUNT)

    async def random_sleep(self, sleep_range: list):
        delay = random.uniform(*sleep_range)
        logger.info(f"[{self.wallet_label}] Sleeping for {delay:.2f}s")
        await asyncio.sleep(delay)

    async def execute_trade(self, symbol: str, action: str):
        try:
            balance = await self.browser.get_balance()
            if balance < 10:
                logger.error(f"[{self.wallet_label}] Insufficient balance: ${balance:.2f}")
                return False

            # Calculate trade amount
            if TRADE_AMOUNTS["amount"][1] > 0:
                trade_amount = random.uniform(*TRADE_AMOUNTS["amount"])
            else:
                percent = random.uniform(*TRADE_AMOUNTS["percent"])
                trade_amount = balance * percent / 100

            # Set leverage
            leverage = random.randint(*TOKENS_TO_TRADE[symbol]["leverage"])
            await self.browser.change_leverage(symbol, leverage)

            # Get current price
            orderbook = await self.browser.get_token_order_book(symbol)
            current_price = orderbook["BUY"] if action == "Long" else orderbook["SELL"]

            # Calculate position size
            position_size = trade_amount * leverage / current_price

            # Create order
            order_data = {
                "symbol": f"{symbol}USDT",
                "side": "BUY" if action == "Long" else "SELL",
                "type": "MARKET",
                "quantity": round(position_size, 4),
            }

            await self.browser.create_order(order_data)

            logger.success(
                f"[{self.wallet_label}] {action} {position_size:.4f} {symbol} "
                f"at ${current_price:.2f} (${trade_amount:.2f}, {leverage}x)"
            )

            return True

        except Exception as e:
            logger.error(f"[{self.wallet_label}] Trade execution failed: {e}")
            return False

    async def close_all_positions(self, symbol: str = None):
        try:
            positions = await self.browser.get_account_positions()
            for position in positions:
                pos_symbol = position["symbol"].replace("USDT", "")
                if symbol and pos_symbol != symbol:
                    continue

                position_amt = Decimal(position["positionAmt"])
                if position_amt != 0:
                    side = "SELL" if position_amt > 0 else "BUY"
                    order_data = {
                        "symbol": position["symbol"],
                        "side": side,
                        "type": "MARKET",
                        "quantity": abs(float(position_amt))
                    }
                    await self.browser.create_order(order_data)
                    logger.info(f"[{self.wallet_label}] Closed {pos_symbol} position")

            return True
        except Exception as e:
            logger.error(f"[{self.wallet_label}] Error closing positions: {e}")
            return False

    async def run_trading_cycle(self):
        logger.info(f"[{self.wallet_label}] Starting trading cycle")

        try:
            available_symbols = list(TOKENS_TO_TRADE.keys())
            
            while self.trades_count < self.max_trades:
                symbol = random.choice(available_symbols)
                available_actions = [action for action, enabled in FUTURE_ACTIONS.items() if enabled]
                
                if not available_actions:
                    logger.error(f"[{self.wallet_label}] No trading actions enabled!")
                    break
                
                action = random.choice(available_actions)
                
                success = await self.execute_trade(symbol, action)
                
                if success:
                    self.trades_count += 1
                    
                    hold_time = random.randint(*PAIR_SETTINGS["position_hold"])
                    logger.info(f"[{self.wallet_label}] Holding position for {hold_time}s")
                    await asyncio.sleep(hold_time)
                    
                    await self.close_all_positions(symbol)
                    
                    if self.trades_count < self.max_trades:
                        await self.random_sleep(SLEEP_AFTER_FUTURE)
                else:
                    await self.random_sleep(SLEEP_BETWEEN_OPEN_ORDERS)
            
            logger.success(f"[{self.wallet_label}] Trading cycle completed: {self.trades_count}/{self.max_trades} trades")

        except Exception as e:
            logger.error(f"[{self.wallet_label}] Trading cycle failed: {e}")


async def process_wallet(wallet_data: dict, wallet_id: int):
    label = f"Wallet_{wallet_id}"
    browser = None
    
    try:
        browser = Browser(
            proxy=wallet_data.get("proxy", ""),
            api_key=wallet_data["api_key"],
            label=label
        )
        
        balance = await browser.get_balance()
        logger.info(f"[{label}] Connected successfully. Balance: ${balance:.2f}")
        
        bot = TradingBot(browser, label)
        await bot.run_trading_cycle()
        
        await asyncio.sleep(random.uniform(*SLEEP_AFTER_ACC))
        
    except Exception as e:
        logger.error(f"[{label}] Critical error: {e}")
    finally:
        if browser:
            await browser.close_session()


async def main():
    WALLETS = [
        {
            "api_key": "your_api_key_here:your_secret_key_here",
            "proxy": "username:password@ip:port"  # optional
        },
        # Add more wallets here...
    ]
    
    if not WALLETS:
        logger.error("No wallets configured!")
        return
    
    if SHUFFLE_WALLETS:
        random.shuffle(WALLETS)
        logger.info("Wallets shuffled")
    
    logger.info(f"Starting trading bot with {len(WALLETS)} wallets")
    
    tasks = []
    for i, wallet_data in enumerate(WALLETS):
        if THREADS > 1:
            task = asyncio.create_task(process_wallet(wallet_data, i + 1))
            tasks.append(task)
            
            if len(tasks) >= THREADS:
                await asyncio.gather(*tasks)
                tasks = []
        else:
            await process_wallet(wallet_data, i + 1)
    
    if tasks:
        await asyncio.gather(*tasks)
    
    logger.success("All wallets processed!")


if __name__ == "__main__":
    logger.add("trading_bot.log", rotation="10 MB", level="INFO")
    asyncio.run(main())